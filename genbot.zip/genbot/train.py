import tensorflow as tf
import tensorflow.keras as krs
import engine


def model():
    d=krs.Input((1,1))
    x=krs.layers.Dense(64)(d)
    #x=krs.layers.GRU(64,return_sequences=True)(x)
    x=krs.layers.GRU(32)(x)
    x=krs.layers.Dense(2)(x)
    return krs.Model(inputs=[d],outputs=[x])

class Replay:
    def __init__(self) -> None:
        pass


if __name__=='__main__':
    mod=None
    try:
        mod=krs.models.load_model('')
    except:
        mod=model()
        mod.compile(loss=krs.losses.MeanSquaredError())
    mod.fit([[[1]]],[[[1]]])
    print(mod.summary())
