import copy
import random
import collections

EMPTY=0
CROWN=1
CITY=2
MOUNTAIN=3
FOG=4
FOG_OBS=5


class Data:
    '''
    List of [terrain, id, number of troops]. Players' names, army, and land.

    Terrain: Empty 0, Crown 1, City 2, Mountain 3, Fog 4, Fog Obstacle 5.

    Id: 0-16, 0 for neutral and 1-16 for players.

    Players receive processed `Data` instances so that they do not have access to the entire board's data. Additional data will not be passed to players.

    Not responsible for validation.

    '''
    


    def __init__(self):
        '''
        `_setMamelist`, `_reset`, `_refresh`.
        '''
        self.__namelist=None
        self.__len=None
        pass

    def terrain(self,ind):
        return self.__data[ind][0]

    def terrains(self):
        return [self.terrain(i) for i in range(self.__len)]

    def _setTerrain(self,ind,x):
        self.__data[ind][0]=x
    
    def id(self,ind):
        return self.__data[ind][1]
    
    def ids(self):
        return [self.id(i) for i in range(self.__len)]
    
    def _setId(self,ind,x):
        self.__data[ind][1]=x

    def troop(self,ind):
        return self.__data[ind][2]

    def troops(self):
        return [self.troop(i) for i in range(self.__len)]

    def _setTroop(self,ind,x):
        self.__data[ind][2]=x
    
    def army(self,id):
        return self._getv('army')[id] if id!=0 else 0

    def armies(self):
        return [self.army(i) for i in range(self.pcnt()+1)]
    
    def _setArmy(self,id,x):
        self._getv('army')[id]=x
    
    def _incArmy(self,id,x):
        self._getv('army')[id]+=x

    def land(self,id):
        return self._getv('land')[id] if id!=0 else 0

    def lands(self):
        return [self.land(i) for i in range(self.pcnt()+1)]

    def _setLand(self,id,x):
        self._getv('land')[id]=x

    def _incLand(self,id,x):
        self._getv('land')[id]+=x

    def _data(self):
        '''
        Returns a copy of self.
        '''
        return copy.deepcopy(self)
    
    def _setNamelist(self,namelist:list):
        if  self.__namelist is not None:raise PermissionError()
        self.__namelist=['Neutral']
        self.__namelist.extend(namelist)
        self.__pcnt=len(self.namelist())-1
        
    def namelist(self):
        return copy.deepcopy(self.__namelist)


    def pcnt(self):
        '''
        Returns the number of players.
        '''
        return self.__pcnt

    def _reset(self,length=0):
        '''
        Resets this instance.
        '''
        if self.__len is not None and self.__len!=length:raise PermissionError()
        self.__data=self.__empty(length)
        self.__len=length
        self._rea()

    def _rea(self):
        '''
        Resets additional data.
        '''
        self.__addt={}
        self.__advis={}
        d,v=self.__addt,self.__advis
        d['pov']=[collections.defaultdict(lambda:0) for i in range(self.pcnt()+1)]
        d['gs']=[set() for i in range(self.pcnt()+1)]
        d['cs']=[set() for i in range(self.pcnt()+1)]
        d['occ']=[set() for i in range(self.pcnt()+1)]
        v['army']=[0 for i in range(self.pcnt()+1)]
        v['land']=[0 for i in range(self.pcnt()+1)]

    def _get(self,st):
        return self.__addt[st]

    def _getv(self,st):
        return self.__advis[st]

    def __empty(self,l):
        return [[0,0,0] for i in range(l)]

    def __len__(self):
        return self.__len




class Player:
    def __init__(self,id,name):
        self.__id=id
        self.__name=name

    def playerID(self):
        return self.__id

    def name(self):
        return self.__name

    def move(self,view):
        pass

class Model:
    '''
    Data manager. The class that defines the rule.

    No fog in `__data`.
    '''
    def __init__(self,turnsPerRound=25,movesPerTurn=2,turn=0,moves=0):
        
        #self.__players=[(i+1,Player()) for i in range(pcnt)]
        self.__data=None
        self.__turnsPerRound=turnsPerRound
        self.__movesPerTurn=movesPerTurn
        self.__turn=turn
        self.__moves=moves
        pass

    def _read(self,data:Data):
        if not self.check(data):
            raise ValueError('Data not vaild')
        self.__data=data

    def _data(self):
        return self.__data._data()
    
    def _pov(self,id):

        '''
        Returns the board in the specified player's Point of View(POV).

        '''
        data=self.__data._data()
        if id<=0 or id>data.pcnt():return data

    def _view(self,ind):
        '''
        Returns which tiles can be seen from the given tile.
        '''
        return []
    
    def _reach(self,ind):
        '''
        Returns to which tiles troops can move from the given tile.
        '''
        return []

    def _capt(self,a,b):
        '''
        Player a captures player b.
        '''
        dat=self.__data
        for i in dat._get('occ')[b]:
            tp=(dat.troop(i)+1)//2
            dat._setTroop(i,tp)
            dat._setId(i,a)
            dat._incArmy(a,tp)
        dat._incLand(a,dat.land(b))
        dat._setArmy(b,0)
        dat._setLand(b,0)

    def _move(self,st,ed,is50):
        '''
        Returns whether this move is successful.
        '''

        dat=self.__data
        if st==0 and ed==0:return True
        if ed not in self._reach(st):return False
        if dat.terrain(st)==MOUNTAIN or dat.terrain(ed)==MOUNTAIN:return False

        if dat.troop(st)<=1:return False
        sts,eds=dat.troop(st),dat.troop(ed)
        if dat.id(st)!=dat.id(ed):
            stid,edid=dat.id(st),dat.id(ed)
            mov=0
            if is50:mov=(sts+1)//2
            else:mov=sts-1
            if mov>eds:
                dat._setTroop(st,sts-mov)
                dat._setTroop(ed,mov-eds-1)
                dat._setId(ed,stid)
                dat._incLand(stid,1)
                dat._incLand(edid,-1)
                if dat.terrain(ed)==CROWN:
                    dat._setTerrain(ed,CITY)
                    dat._get('gs')[edid].remove(ed)
                    dat._get('cs')[stid].add(ed)
                    if len(dat._get('gs'))==0:
                        self._capt(stid,edid)
                elif dat.terrain(ed)==CITY:
                    dat._get('cs')[edid].remove(ed)
                    dat._get('cs')[stid].add(ed)
            else:
                dat._setTroop(st,sts-mov)
                dat._setTroop(ed,eds-mov)
        else:
            dat._setTroop(st,1)
            dat._setTroop(ed,sts+eds-1)
        return True
        
    def check(self,data:Data,nearest=0):
        '''
        Returns whether the specified `Data` instance is vaild in this model.
        '''
        try:
            g=None
            for i in data._get('gs')[1]:
                g=i
                break
            l=collections.deque([g])
            vis=collections.defaultdict(lambda:-1)
            vis[g]=0

            cnt=0
            while len(l)!=0:
                u=l.popleft()
                if data.terrain(u)==CROWN:cnt+=1
                for j in self._reach(u):
                    if data.terrain(j)==MOUNTAIN or data.terrain(j)==CITY or vis[j]!=-1:continue
                    l.append(j)
                    vis[j]=0

            if cnt!=data.pcnt():return False

            for id in range(1,1+data.pcnt()):
                for g in data._get('gs')[id]:
                    l.clear()
                    l.append(g)
                    vis.clear()
                    vis[g]=0
                    while len(l)!=0:
                        u=l.popleft()
                        for j in self._reach(u):
                            if vis[j]!=-1:continue
                            if data.terrain(j)==CROWN:return False
                            vis[j]=vis[u]+1
                            if vis[j]<nearest:l.append(j)
        except Exception:
            return False
                
        return True
    
    def _refresh(self,data:Data):
        '''
        Refreshes additional data of this `Data` instance.

        Additional data: `__gs`, `__cs`, `__pov`, `__troop`, `__land`, `__occ`.
        '''
        data._rea()
        for i in range(len(data)):
            id=data.id(i)
            if id>data.pcnt() or id<0:raise ValueError()
            if id==0:continue
            data._get('occ')[id].add(i)
            data._incArmy(id,data.troop(i))
            data._incLand(id,1)
            for j in self._view(i):
                data._get('pov')[id][j]+=1
            if data.terrain(i)==CITY:
                data._get('cs')[id].add(i)
            elif data.terrain(i)==CROWN:
                data._get('gs')[id].add(i)
            

    def movesPerTurn(self):
        return self.__movesPerTurn
    
    def turnsPerRound(self):
        return self.__turnsPerRound

    def turn(self):
        return self.__turn

    def moves(self):
        return self.__moves


class GameModel(Model):

    def __init__(self, turnsPerRound=25, movesPerTurn=2, turn=0, moves=0):
        super().__init__(turnsPerRound=turnsPerRound, movesPerTurn=movesPerTurn, turn=turn, moves=moves)

        self.__players=[]

    def _next(self):
        for i,player in self.__players:
            player.move(self._pov(i))
        self.__moves+=1
        if self.__moves==self.__movesPerTurn:
            self.__moves=0
            self.__turn+=1
            self._newturn()
        if self.__turn%self.__turnsPerRound==0:self._newround()
        self.__players.append(self.__players.pop(0))

    def _newturn(self,):
        pass

    def _newround(self):
        pass

    def _read(self, data: Data):
        return super()._read(data)
        
class SquareModel(GameModel):

    def __init__(self, turnsPerRound=25, movesPerTurn=2, turn=0, moves=0, **kwargs):
        super().__init__(turnsPerRound=turnsPerRound, movesPerTurn=movesPerTurn, turn=turn, moves=moves)

        self.__row=kwargs.get('row',0)
        self.__col=kwargs.get('col',0)
        self.__size=self.__row*self.__col

    def _view(self,ind):
        if ind<0 or ind>=self.__size:return []
        l=[]
        r,c=ind//self.__col,ind%self.__col
        for i in range(-1,2):
            for j in range(-1,2):
                if self.__judgeR(r+i) and self.__judgeC(c+j):
                    l.append(self.index(r+i,c+j))
        return l
    
    def _reach(self, ind):
        if ind<0 or ind>=self.__size:return []
        l=[]
        r,c=ind//self.__col,ind%self.__col
        if r>0:
            l.append(self.index(r-1,c))
        if r<self.row()-1:
            l.append(self.index(r+1,c))
        if c>0:
            l.append(self.index(r,c-1))
        if c<self.col()-1:
            l.append(self.index(r,c+1))
        return l

    def __judgeR(self,r):
        '''
        Returns whether row number `r` is vaild.
        '''
        return r>=0 and r<self.__row

    def __judgeC(self,c):
        return c>=0 and c<self.__col

    def index(self,row,col):
        return self.__col*row+col

    def _read(self, data: Data):
        super()._read(data)
        l=len(data)
        if self.__row==0:
            if self.__col==0 or l%self.__col!=0:raise ValueError()
            self.__row=l//self.__col
        elif self.__col==0:
            if l%self.__row!=0:raise ValueError()
            self.__col=l//self.__row
        self.__size=self.row()*self.col()

    def row(self):
        return self.__row

    def col(self):
        return self.__col


class MapGenerator:

    def __init__(self):
        raise PermissionError()


    @staticmethod
    def sq_12x12_1v1(max=10):
        '''
        Generates a model of size 12x12 and 2 players.
        '''
        mod=SquareModel(row=12,col=12)
        d=Data()
        d._setNamelist(['player1','player2'])
        d._reset(144)
        mod._refresh(d)
        

        for jb in range(max):
            d._reset(144)
            b=0
            gs=set(random.sample(range(144),2))
            ids=random.sample([1,2],2)
            
            for i in range(144):
                if i in gs:
                    d._setTerrain(i,CROWN)
                    d._setId(i,ids[b])
                    d._setTroop(i,1)
                    b+=1
                elif random.randint(0,3)==0:
                    d._setTerrain(i,MOUNTAIN)
                elif random.randint(0,30)==0:
                    d._setTerrain(i,CITY)
                    d._setTroop(i,random.randint(30,40))
            mod._refresh(d)
            
            if mod.check(d,9):break
        
        mod._read(d)
        return mod

print(dir(Data()))