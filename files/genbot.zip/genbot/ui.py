import pygame
import pygame.display
import pygame.draw
import pygame.event
import pygame.font
import pygame.image
import pygame.locals
import pygame.transform
import engine

display=pygame.display
event=pygame.event
locals=pygame.locals
setattr(pygame.locals,'GAME',pygame.event.custom_type())


COLORS=[(128,128,128),(190,0,0),(70,100,220),(128,0,128),(0,128,128),(128,0,0),(0,128,0),(0,0,255),(0,128,255)]

font:pygame.font.Font=None
images={}

def img(file):
    return pygame.image.load(file)
    

def scale(scr,a,b):
    return pygame.transform.smoothscale(scr,(a,b))

def init():
    global font,images
    pygame.init()
    font=pygame.font.Font('res/Quicksand-Regular.otf',18)
    images[engine.CROWN]=img('res/crown.png')
    images[engine.CITY]=img('res/city.png')
    images[engine.MOUNTAIN]=img('res/mountain.png')
    images[engine.FOG_OBS]=img('res/obstacle.png')


def create(a,b):
    return pygame.display.set_mode((a,b),flags=pygame.DOUBLEBUF)

def width(font:pygame.font.Font,st):
    return sum([p[4] for p in font.metrics(str(st))])

def intfont(st,maxw):
    if width(font,st)>=maxw:
        st='%.0e'%st
        p=list(str(st))
        for k in range(len(p)):
            if p[k]=='0' and p[k-1]=='':
                p[k]=''
            if p[k]=='+':
                p[k]=''
        st=''.join(p)
    else:st=str(st)
    return font.render(st,True,(255,255,255))
    
def center(x,y,rect):
    return (rect[0]+(rect[2]-x)//2,rect[1]+(rect[3]-y)//2)



def paint(scr:pygame.Surface,mod:engine.Data,**kwargs):
    if isinstance(mod,engine.SquareData):
        sz=kwargs['size']
        dat=mod._data()
        ims={}
        for k in images:
            ims[k]=scale(images[k],int(sz*0.8),int(sz*0.8))
        for i in range(mod.row()):
            for j in range(mod.col()):
                ind=mod.index(i,j)
                rect=(j*sz,i*sz,sz,sz)
                if dat.terrain(ind)==engine.MOUNTAIN:
                    scr.fill((184,184,184),rect)

                elif dat.id(ind)!=0 or dat.troop(ind)!=0:
                    scr.fill(COLORS[dat.id(ind)],rect)
                else:
                    scr.fill((255,255,255),rect)
                pygame.draw.rect(scr,(0,0,0),rect,1)
                if dat.terrain(ind) in images:
                    im=ims[dat.terrain(ind)]
                    scr.blit(im,center(im.get_width(),im.get_height(),rect))

                if dat.troop(ind)!=0 or (dat.id(ind)==0 and dat.terrain(ind)==engine.CITY):
                    f=intfont(dat.troop(ind),sz)
                    scr.blit(f,center(f.get_width(),f.get_height(),rect))
def quit():
    pygame.quit()
