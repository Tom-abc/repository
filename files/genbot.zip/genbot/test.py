import engine
import ui

mod=engine.MapGenerator.sq_12x12_1v1(100)
ui.init()
scr=ui.create(800,800)
ui.event.set_blocked(None)
ui.event.set_allowed([ui.locals.QUIT])
print(mod._data().armies())

while True:
    e=ui.event.wait()
    if e.type==ui.locals.QUIT:break
    scr.fill((34,34,34))
    ui.paint(scr,mod,size=60)
    ui.display.flip()
ui.quit()
